import{V as a,b2 as m}from"./index-u37HeVso.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
